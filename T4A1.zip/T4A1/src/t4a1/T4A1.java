package t4a1;

import java.util.Scanner;

/**
 *
 * @author esmer
 */
public class T4A1 {

    public static void main(String[] args) {
        numeros();
   //     confecciones();
   //     calificaciones();
   //     multiplos();
    }

    public static void numeros() {
        Scanner obj = new Scanner(System.in);
        System.out.print("MUESTRA DE NUMEROS POSITIVOS\n\nIngrese un numero positivo: ");
        int n = obj.nextInt();
        if (n > 0) {
            int j = 1;
            while (j <= n) {
                System.out.println(j);
                j++;
            }

        } else {
            System.out.println("Su numero no es positivo");
        }
    }

    public static void confecciones() {
        Scanner obj = new Scanner(System.in);
        System.out.print("CONFECCIONES DE PANTALONES POR TALLA\n\nIngrese su nombre: ");
        String n = obj.next();
        System.out.print("Ingrese el numero de piezas a confeccionar: ");
        int p = obj.nextInt();
        System.out.println("Las tallas pueden ser: S, M, L y XL");
        int c = 1;
        int s = 0, m = 0, l = 0, xl = 0, i=0;
        while (c <= p) {
            System.out.print("Ingrese la talla de la prenda " + c + ": ");
            String t = obj.next();   
            if (t.equals("S")||t.equals("s")) {
                s = s+1;
            } else if (t.equals("M")||t.equals("m")) {
                m = m+1;
            } else if (t.equals("L")||t.equals("l")) {
                l = l+1;
            } else if (t.equals("XL")||t.equals("xl")) {
                xl = xl+1;
            }else{
            i=i+1;
            }
            c++;
        }
        System.out.println(n + " en su pedido de " + p + " piezas hay:\n" + s
                        + " piezas de talla S\n" + m + " piezas de talla M\n" + l + " piezas de talla L\n" + xl
                        + " piezas de talla XL\n"+i+" tallas incorrectas");
    }
    
    public static void calificaciones(){
    Scanner obj = new Scanner(System.in);
        System.out.print("CALIFICACIONES DE ESTUDIANTES\n\nIngrese el numero de estudiantes: ");
        int e=obj.nextInt();
        int j=1;
        int a=0, r=0, i=0;
        System.out.println("\nIngrese las calificaciones en escala de 0 a 100");
        while(j<=e){
            System.out.print("Calificacion del estudiante "+j+": ");
            int c=obj.nextInt();
            if(c>=70 && c<101){
                a++;
            }else if(c>=0 && c<70){
            r++;
            }else{
            i++;
            }
            j++;
        }
        System.out.println("\nEl numero de estudiantes con calificacion mayor o igual a 70 es: "+a+
                "\nEl numero de estudiantes con calificacion menor a 70 es: "+r+
                "\nCalificaciones invalidas: "+i);
    }
    
    public static void multiplos(){
     Scanner obj = new Scanner(System.in);
        System.out.print("MULTIPLOS DE UN NUMERO\n\nIngrese un numero: ");
        int n=obj.nextInt();
        System.out.print("Ingrese el numero limite: ");
        int l=obj.nextInt();
        int j=n;
        while(j<=l){
            System.out.println("Multiplo: "+j);
        j=j+n;
            
        }
    }

}
